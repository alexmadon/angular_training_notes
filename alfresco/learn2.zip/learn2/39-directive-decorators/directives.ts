import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: 'directives.html'
})
export class DirectivesComponent {

}
