import {Component} from '@angular/core';

declare var __moduleName: string;

@Component({
  moduleId: __moduleName,
  templateUrl: './contacts.component.html'
})
export class Contacts {

}
