# Workshop for this step

Your customer would like to see the list populated with some example
archetypes. You will need to find or create some data that shows some
basic stats for a collection of entities. For convenience, we have
provided some of the data used by SWAPP in the learn2 directory under
demo-data. You can use this data or copy its structure if you would like
to create your own dataset.

## Step 1: Update the archetypeList Component to Include Data

Once you have a collection of data, add it to the archetypeList
Component.

However...

## Step 2: Use ngFor to Display Each Entry in the Collection

You have not been given all of the tools you need to pass the data for
each entry into an archetype display just yet. For now, just use a bit
of template right in your list component, with ngFor.
