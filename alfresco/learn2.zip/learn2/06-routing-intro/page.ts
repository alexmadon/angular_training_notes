import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: './page.html'
})
export class PageComponent {
}
