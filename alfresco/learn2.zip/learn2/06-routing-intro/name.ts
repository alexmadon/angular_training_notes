import { Component } from '@angular/core';

@Component({
  selector: 'some-name',
  template: `
    <div class="card">
      <div class="card-content">
        <div class="card-title">Hello Bubba!</div>
        <p>This is another example component.</p>
      </div>
    </div>
  `
})
export class NameComponent {
}
