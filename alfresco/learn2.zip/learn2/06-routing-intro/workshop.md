# Workshop for this step

The instructor may have changes to the workshops, as our curriculum is
under continuous improvement and is adjusted for the needs of each
class.

Add another route to the application:

1. Create a new component, with a simple static template.
2. Add the component to imports in AppModule.
3. Add a link to the navbar which routes to the new component.
