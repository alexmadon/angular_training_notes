# Workshop for this step

Make your own wrapper component.
