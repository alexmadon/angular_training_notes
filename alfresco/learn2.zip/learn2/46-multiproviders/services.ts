
export class FirstService {
  val: number = 1;
}

export class SecondService {
  val: number = 2;
}
