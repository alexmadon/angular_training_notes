import {Component} from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: './binding.html'
})
export class BindingComponent {
  name: string = 'John';
}
