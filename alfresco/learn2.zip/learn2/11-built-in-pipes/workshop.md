# Workshop for this step

Use the JSON Pipe, or another pipe, to improve the display of data in
your application.
