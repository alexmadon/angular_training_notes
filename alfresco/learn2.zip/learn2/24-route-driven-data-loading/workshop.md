# Workshop for this step

Add route driven data loading to your project. You already have a list
of things on the screen - make it so that clicking on one will load
details about that one in another screen/route.

You can request a single item from the JSON server, as long as the items
in the array contain an "id" property:
http://localhost:8085/employees/(id)
