# Workshop for this step

The instructor may have changes to the workshops, as our curriculum is
under continuous improvement and is adjusted for the needs of each
class.

1. Add a few more fields in the component class.
2. Add data for the new the fields.
3. Bind to them in the template.
4. Experiment with HTML in the binding strings.
