# Workshop for this step

The work continues to fetch data using an API. Update the service you
created to load your data with HTTP.
