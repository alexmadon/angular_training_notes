# Workshop for this step

1. Extend the functionality of the app in some way,
   from something as minor as a visual change or as
   major as a new API or new feature.
