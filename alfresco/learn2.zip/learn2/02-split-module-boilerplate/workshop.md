# Workshop for this step

The instructor may have changes to the workshops, as our curriculum is
under continuous improvement and is adjusted for the needs of each
class.

If you just did the workshop for the previous step, you are done! If
you started with step 2, the workshop is:

1. Make sure you can view the step in your browser.
2. Make a trivial adjustment to the displayed text in first.ts.
3. Verify changes appear in your browser.
