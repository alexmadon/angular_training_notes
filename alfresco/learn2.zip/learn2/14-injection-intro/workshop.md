# Workshop for this step

1. Inject Title into one of your components
2. Set the title programmatically
