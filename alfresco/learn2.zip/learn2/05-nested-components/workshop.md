# Workshop for this step

The instructor may have changes to the workshops, as our curriculum is
under continuous improvement and is adjusted for the needs of each
class.

1. Add at least one more component to this application.
2. Use it inside the app component.
3. Inspect the DOM using the browser development tools.
4. Try rearranging the order in declarations.
   Does the app still work?
5. See what happens if you try to use two components
   mutually inside each other.
