# Workshop for this step

Use routing in your application:

1. Use a route parameter in one of your routes (either an existing or new one)
