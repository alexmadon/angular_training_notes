import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: './example.html'
})
export class ExampleComponent {
}
